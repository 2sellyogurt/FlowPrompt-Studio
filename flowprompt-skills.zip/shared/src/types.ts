// 核心数据类型定义
export interface Attempt {
  id?: string;
  description: string;
  result: 'success' | 'failure';
  logs: string;
}

export interface Criteria {
  description: string;
  metric: string;
  targetValue: string;
}

export interface FlowPromptData {
  targetAI: string;
  step1: {
    projectType: string;
    techStack: string[];
    problemDescription: string;
  };
  step2: {
    attempts: Attempt[];
  };
  step3: {
    coreProblem: string;
    constraints: string[];
  };
  step4: {
    acceptanceCriteria: Criteria[];
  };
  step5: {
    functionalBoundaries: string;
    technicalBoundaries: string;
    excludedFeatures: string[];
  };
}

export enum FormState {
  EMPTY = 'empty',
  FILLING = 'filling',
  VALIDATING = 'validating',
  VALID = 'valid',
  EXCELLENT = 'excellent',
  SAVED = 'saved',
  SENT_TO_TRAE = 'sent_to_trae'
}

export interface FormValidationResult {
  isValid: boolean;
  score: number;
  errors: string[];
  warnings: string[];
  state: FormState;
}

export interface Draft {
  id: string;
  name: string;
  formData: FlowPromptData;
  createdAt: string;
  updatedAt: string;
}

export interface ConnectorResult {
  success: boolean;
  message: string;
  data?: any;
}

export interface SkillResponse<T> {
  success: boolean;
  message: string;
  data?: T;
  error?: string;
}

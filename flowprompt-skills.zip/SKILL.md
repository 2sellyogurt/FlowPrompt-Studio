---
name: flowprompt
description: 别再让AI猜你要什么了 — 3分钟把模糊想法变成高质量Prompt，AI一次就给出满意答案
version: "3.1.0"
author: FlowPrompt Studio Team
license: "AGPL-3.0"
allowed-tools:
  - Read
  - Write
  - SearchReplace
  - Glob
  - Grep
  - LS
  - DeleteFile
  - RunCommand
---

# FlowPrompt Studio v3.1

> 还在反复跟 AI 对话才得到满意答案？FlowPrompt 帮你把模糊需求结构化，生成高质量 Prompt，让 AI 一次就懂、一次就对。
> 6 个子技能协同工作：从一句话想法到专业级 Prompt，全程引导，零门槛上手。

## 你会遇到这些问题吗？

- 😤 跟 AI 说了半天，它给的答案总是跑偏
- 🔄 同一个问题要来回改 5、6 轮才勉强能用
- 🤔 知道自己想要什么，但不知道怎么描述才能让 AI 理解
- 😱 复杂项目交给 AI，结果完全不符合预期

**FlowPrompt Studio 就是来解决这些问题的。**

## 核心流程

```
一句话想法 → [智能收敛] → 结构化需求 → [质量评分] → 高质量Prompt → [发送] → AI助手
                ↑               ↑              ↑              ↑
           5轮对话引导      7维度表单      100分评分体系    多平台支持
```

## 技能列表（6个子技能）

### 1. FlowPrompt-Converge（需求收敛引擎）🆕
- **ID**: flowprompt-converge
- **描述**: 跟你聊 5 轮，把模糊想法变成清晰的结构化需求。也可以一键快速收敛，30 秒出结果
- **入口**: skills/flowprompt-converge/index.js
- **Actions**: `start`, `answer`, `quickConverge`, `getNextQuestion`, `validateDraft`
- **标签**: convergence, nlp, extraction

### 2. FlowPrompt-Form（结构化表单）
- **ID**: flowprompt-form
- **描述**: 7 个维度帮你把需求说清楚：项目定义、功能需求、测试标准、开发要求、风险管控、验收条件、输出格式
- **入口**: skills/flowprompt-form/index.js
- **Actions**: `getEmptyForm`, `getProjectTypeOptions`, `getTargetAIOptions`, `getRequiredFields`, `validateForm`, `updateForm`
- **标签**: form, data-management

### 3. FlowPrompt-Validator（质量评分）
- **ID**: flowprompt-validator
- **描述**: 给你的需求打分（满分 100），告诉你哪里没说清楚，还有 6 项硬约束帮你避坑
- **入口**: skills/flowprompt-validator/index.js
- **Actions**: `validate`, `generateSummary`, `canGeneratePrompt`
- **标签**: validation, scoring, quality-assurance

### 4. FlowPrompt-Generator（Prompt 生成器）
- **ID**: flowprompt-generator
- **描述**: 根据结构化需求自动生成专业 Prompt，包含完整的上下文、约束和验收标准
- **入口**: skills/flowprompt-generator/index.js
- **Actions**: `generate`, `generateSummary`, `optimizePrompt`
- **标签**: prompt, generator

### 5. FlowPrompt-Draft（草稿管理）
- **ID**: flowprompt-draft
- **描述**: 随时保存进度，支持多个项目草稿，下次接着来
- **入口**: skills/flowprompt-draft/index.js
- **Actions**: `save`, `read`, `update`, `delete`, `list`, `getLatest`, `clear`
- **标签**: draft, persistence

### 6. FlowPrompt-Connector（AI 连接器）
- **ID**: flowprompt-connector
- **描述**: 一键发送到 Trae CN、豆包、DeepSeek、GPT、Claude、Cursor、Copilot 等 AI 助手
- **入口**: skills/flowprompt-connector/index.js
- **Actions**: `sendToAI`（兼容`sendPrompt`）, `checkConnection`, `getSupportedAIList`
- **标签**: ai, connector

## 7 维度需求覆盖

| 维度 | 解决什么问题 | 评分权重 |
|------|-------------|:-------:|
| 项目基础 | 这是什么项目？给谁用的？ | 30分 |
| 功能需求 | 具体要做什么？做到什么程度？ | 25分 |
| 测试标准 | 怎么算做对了？ | 15分 |
| 开发要求 | 用什么技术？有什么限制？ | 10分 |
| 风险管控 | 哪些地方容易出问题？ | 10分 |
| 验收条件 | 最终交付物长什么样？ | 10分 |
| 输出配置 | 要什么格式的结果？ | +5分 |

## 评分体系

```
满分 = 100分
  需求清晰度越高 → 分数越高 → 生成的 Prompt 质量越好

一票否决: 6 项硬约束（项目名称、核心目标、技术栈、
          运行环境、合规要求、数据安全）
          触发任一项 → 提示补充后才可生成
```

## 使用场景

- 🛠️ **AI 编程**: 把模糊的开发需求变成 AI 能理解的专业描述
- 📝 **内容创作**: 让 AI 一次性生成符合要求的文案、报告
- 📊 **数据分析**: 清晰描述分析目标和预期输出
- 🎨 **设计需求**: 把设计想法结构化，让 AI 辅助出图
- 💼 **项目管理**: 快速生成项目文档和需求说明

## 版本历史

- **v1.0.0**: 初始版本，5步表单，五步均分评分
- **v3.0.0**: 重构为7表单全链路体系，6阶段权重评分，一票否决
- **v3.1.0**: 新增需求收敛引擎（converge），支持模糊输入→结构化Prompt

## 许可证

[AGPL-3.0](https://www.gnu.org/licenses/agpl-3.0.html) — GNU Affero General Public License v3.0

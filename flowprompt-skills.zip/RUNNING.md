# FlowPrompt Studio 技能运行描述与工作流

## 技能概述

FlowPrompt Studio 是一个 AI Prompt 质量提升工具。它解决的核心问题是：**用户对 AI 提问太模糊，导致 AI 反复给错答案，浪费大量时间来回修改。**

通过 6 个子技能协同工作，帮你把一句话的模糊想法，变成结构清晰、约束明确的高质量 Prompt，让 AI 一次就给出满意答案。

## 技能运行环境

### 系统要求
- **运行环境**: SOLO 平台沙箱环境
- **工作目录**: /data/user/work（临时文件）、/workspace（最终交付物）
- **技能存放**: /data/user/skills/（用户技能）或 /data/user/builtin/（内置技能）
- **依赖**: 可选依赖 `node-fetch@^3.3.2`（用于网络请求）

### 可用工具
- 文件操作：Read、Write、SearchReplace、Glob、Grep、LS、DeleteFile
- 命令执行：RunCommand（Bash）
- 网络：WebSearch、WebFetch
- 浏览器：MCP Browser 工具
- 技能调用：Skill 工具
- 子代理：Task（Explore / Plan / general_purpose_task）
- 图片生成：GenerateImage

## 核心技能运行描述

### 1. FlowPrompt-Converge（需求收敛引擎）🆕

**功能**: 跟用户聊 5 轮，把模糊想法变成清晰的结构化需求。也支持一键快速收敛模式

**运行流程**:
1. **启动收敛**: 调用 `start` 开始交互式收敛流程
2. **回答问题**: 调用 `answer` 提交用户回答，系统逐步引导梳理需求
3. **快速收敛**: 调用 `quickConverge` 一键从模糊描述生成结构化数据
4. **获取下一题**: 调用 `getNextQuestion` 获取当前应回答的问题
5. **验证草稿**: 调用 `validateDraft` 检查收敛结果是否完整

### 2. FlowPrompt-Form（结构化表单）

**功能**: 7 个维度帮你把需求说清楚——项目定义、功能需求、测试标准、开发要求、风险管控、验收条件、输出格式

**运行流程**:
1. **获取空表单**: 调用 `getEmptyForm` 获取默认表单结构
2. **获取选项**: 调用 `getProjectTypeOptions` 和 `getTargetAIOptions` 获取可用选项
3. **获取必填项**: 调用 `getRequiredFields` 查看哪些字段必须填写
4. **验证表单**: 调用 `validateForm` 验证表单数据完整性
5. **更新表单**: 调用 `updateForm` 更新表单数据

### 3. FlowPrompt-Validator（质量评分）

**功能**: 给你的需求打分（满分 100），告诉你哪里没说清楚，6 项硬约束帮你避坑

**运行流程**:
1. **验证表单**: 调用 `validate` 验证表单数据并计算质量评分
2. **生成摘要**: 调用 `generateSummary` 生成验证摘要
3. **检查生成条件**: 调用 `canGeneratePrompt` 检查是否满足生成 Prompt 的条件

### 4. FlowPrompt-Generator（Prompt 生成器）

**功能**: 根据结构化需求自动生成专业 Prompt，包含完整的上下文、约束和验收标准

**运行流程**:
1. **生成 Prompt**: 调用 `generate` 根据表单数据生成标准化 Prompt
2. **生成摘要**: 调用 `generateSummary` 生成 Prompt 摘要
3. **优化 Prompt**: 调用 `optimizePrompt` 优化 Prompt 格式

### 5. FlowPrompt-Draft（草稿管理）

**功能**: 随时保存进度，支持多个项目草稿，下次接着来

**运行流程**:
1. **保存草稿**: 调用 `save` 保存表单数据为草稿
2. **读取草稿**: 调用 `read` 获取指定 ID 的草稿
3. **获取草稿列表**: 调用 `list` 获取所有草稿
4. **获取最新草稿**: 调用 `getLatest` 获取最新保存的草稿
5. **更新草稿**: 调用 `update` 更新草稿内容
6. **删除草稿**: 调用 `delete` 删除指定草稿
7. **清空草稿**: 调用 `clear` 清空所有草稿

### 6. FlowPrompt-Connector（AI 连接器）

**功能**: 一键发送到 Trae CN、豆包、DeepSeek、GPT、Claude、Cursor、Copilot 等 AI 助手

**运行流程**:
1. **发送 Prompt**: 调用 `sendToAI`（兼容 `sendPrompt`）发送 Prompt 到指定的 AI 助手
2. **检查连接状态**: 调用 `checkConnection` 检查 AI 助手的连接状态
3. **获取 AI 列表**: 调用 `getSupportedAIList` 获取支持的 AI 助手列表

## 完整工作流

### 标准工作流

1. **需求收敛**
   - 调用 FlowPrompt-Converge 技能，通过对话把模糊想法结构化
   - 或直接使用 FlowPrompt-Form 手动填写

2. **表单填写与验证**
   - 调用 FlowPrompt-Form 技能获取和更新表单
   - 调用 FlowPrompt-Validator 技能进行质量评分

3. **Prompt 生成**
   - 调用 FlowPrompt-Generator 技能生成标准化 Prompt
   - 优化 Prompt 格式

4. **草稿管理**
   - 调用 FlowPrompt-Draft 技能保存草稿

5. **发送到 AI**
   - 调用 FlowPrompt-Connector 技能发送 Prompt 到 AI 助手

### 工作流示例

```javascript
// 1. 快速收敛（从模糊想法到结构化需求）
const convergeResult = await flowprompt.callSkill('converge', 'quickConverge', {
  idea: '我想做一个响应式导航栏组件'
});

// 2. 填写表单
const emptyForm = await flowprompt.callSkill('form', 'getEmptyForm');
const updatedForm = await flowprompt.callSkill('form', 'updateForm', {
  currentData: emptyForm.data,
  updates: convergeResult.data
});

// 3. 质量评分
const validation = await flowprompt.callSkill('validator', 'validate', updatedForm.data);
const canGenerate = await flowprompt.callSkill('validator', 'canGeneratePrompt', validation.data);

// 4. 生成 Prompt
if (canGenerate.data.canGenerate) {
  const prompt = await flowprompt.callSkill('generator', 'generate', updatedForm.data);
  const optimizedPrompt = await flowprompt.callSkill('generator', 'optimizePrompt', prompt.data);
  
  // 5. 保存草稿
  await flowprompt.callSkill('draft', 'save', {
    name: '响应式导航栏组件',
    formData: updatedForm.data
  });
  
  // 6. 发送到 AI
  const result = await flowprompt.callSkill('connector', 'sendToAI', {
    aiType: 'trae-cn',
    prompt: optimizedPrompt.data
  });
}
```

## 配置选项

### 全局配置
- **default_ai**: 默认 AI 助手（默认：trae-cn）
- **max_drafts**: 最大草稿数（默认：100）
- **prompt_timeout**: Prompt 超时时间（默认：30000ms）

### 环境变量
- **NODE_ENV**: 运行环境（development/production）
- **FLOWPROMPT_DEBUG**: 是否启用调试模式（true/false）

## 错误处理

所有技能操作都会返回标准的响应格式：

```javascript
{
  success: boolean,        // 操作是否成功
  message: string,         // 操作结果消息
  data: any,              // 操作返回的数据
  error: string           // 错误信息（如果失败）
}
```

## 性能基准（1000次迭代）

| 操作 | 单次耗时 |
|------|:-------:|
| Form加载 | 0.007ms |
| Validator评分 | 0.006ms |
| Generator生成 | 0.042ms |
| 完整流程 | 0.045ms |

## 平台兼容性

- **SOLO 平台**: 完全支持
- **龙虾平台**: 完全支持
- **其他平台**: 可通过适配器实现兼容

## 版本历史

- **v1.0.0**: 初始版本，5步表单，五步均分评分
- **v3.0.0**: 重构为7表单全链路体系，6阶段权重评分，一票否决
- **v3.1.0**: 新增需求收敛引擎（converge），支持模糊输入→结构化Prompt

/**
 * FlowPrompt Studio - 全链路工程化AI开发技能集
 * Copyright (C) 2026 FlowPrompt Studio Team
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Affero General Public License as published
 * by the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU Affero General Public License for more details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program. If not, see <https://www.gnu.org/licenses/>.
 */

// FlowPrompt Studio 技能集主入口

const FlowPromptForm = require('./skills/flowprompt-form');
const FlowPromptValidator = require('./skills/flowprompt-validator');
const FlowPromptGenerator = require('./skills/flowprompt-generator');
const FlowPromptDraft = require('./skills/flowprompt-draft');
const FlowPromptConnector = require('./skills/flowprompt-connector');
const FlowPromptConverge = require('./skills/flowprompt-converge');

class FlowPromptSkills {
  constructor() {
    this.skills = {
      form: new FlowPromptForm(),
      validator: new FlowPromptValidator(),
      generator: new FlowPromptGenerator(),
      draft: new FlowPromptDraft(),
      connector: new FlowPromptConnector(),
      converge: new FlowPromptConverge()
    };
  }

  /**
   * 获取所有技能
   */
  getSkills() {
    return this.skills;
  }

  /**
   * 调用指定技能
   */
  async callSkill(skillName, action, data) {
    try {
      const skill = this.skills[skillName];
      if (!skill) {
        return {
          success: false,
          message: '技能不存在',
          error: `未找到技能: ${skillName}`
        };
      }

      const result = await skill.run({ action, data });
      return result;
    } catch (error) {
      return {
        success: false,
        message: '调用技能失败',
        error: error.message
      };
    }
  }

  /**
   * 运行完整的 FlowPrompt 流程
   */
  async runFlow(data) {
    try {
      // 1. 验证表单数据
      const validationResult = await this.callSkill('validator', 'validate', data);
      if (!validationResult.success || !validationResult.data.isValid) {
        return {
          success: false,
          message: '表单验证失败',
          error: validationResult.data?.errors?.join(', ') || '验证失败'
        };
      }

      // 2. 生成 Prompt
      const generateResult = await this.callSkill('generator', 'generate', data);
      if (!generateResult.success) {
        return {
          success: false,
          message: 'Prompt 生成失败',
          error: generateResult.error
        };
      }

      // 3. 发送到 AI 助手
      const sendResult = await this.callSkill('connector', 'sendToAI', {
        aiName: data.targetAI,
        prompt: generateResult.data
      });

      return {
        success: true,
        message: 'FlowPrompt 流程执行成功',
        data: {
          validation: validationResult.data,
          prompt: generateResult.data,
          sendResult: sendResult.data
        }
      };
    } catch (error) {
      return {
        success: false,
        message: '流程执行失败',
        error: error.message
      };
    }
  }
}

module.exports = FlowPromptSkills;
module.exports.FlowPromptForm = FlowPromptForm;
module.exports.FlowPromptValidator = FlowPromptValidator;
module.exports.FlowPromptGenerator = FlowPromptGenerator;
module.exports.FlowPromptDraft = FlowPromptDraft;
module.exports.FlowPromptConnector = FlowPromptConnector;
module.exports.FlowPromptConverge = FlowPromptConverge;

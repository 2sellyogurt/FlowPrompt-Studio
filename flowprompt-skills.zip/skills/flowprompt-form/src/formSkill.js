/**
 * FlowPrompt Studio - 全链路工程化AI开发技能集
 * Copyright (C) 2026 FlowPrompt Studio Team
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Affero General Public License as published
 * by the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU Affero General Public License for more details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program. If not, see <https://www.gnu.org/licenses/>.
 */

// FlowPrompt-Form 技能 v3.0
// 基于"6表单全链路工程化AI开发体系"重构
// 7表单（表单0-6）核心必填字段键入

class FlowPromptFormSkill {
  getEmptyForm() {
    return {
      success: true,
      message: '获取空表单成功（7表单全链路体系 v3.0）',
      data: {
        form0: {
          projectId: '', formVersion: 'v1.0.0', lifecycle: '规划中',
          projectName: '', coreGoal: '', coreValue: [], targetUsers: '', deliverables: [],
          hostEnv: '', techStackConstraint: '', complianceDomain: '', dataPolicy: '', licenseReq: '', perfBaseline: '',
          startDate: '', launchDate: '', milestones: '',
          productOwner: '', techOwner: '', testOwner: '', complianceOwner: '', changeApproval: '',
          customFields: []
        },
        form1: {
          linkedProjectId: '', prdStatus: '编写中',
          userRoles: [], scenarios: [], userStories: [],
          modules: [], features: [], moduleRelations: '',
          nonFunctional: { performance: '', security: '', compatibility: '', experience: '', compliance: '', maintainability: '', other: '' },
          changeControl: { gradingRules: '', impactAssessment: '', changeHistory: [] },
          review: { entryCriteria: '', passCriteria: '', reviewRecords: [], nextPhaseNote: '' }
        },
        form2: {
          linkedProjectId: '', linkedPrdVersion: '', tddStatus: '用例设计中',
          moduleAcceptance: [], testCases: [], nonFuncCases: [],
          testEnv: { overview: '', tools: '', dataSpec: '', dependencies: '' },
          defectRules: { grading: '', commitGate: '', regression: '', changeSync: '' },
          review: { entryCriteria: '', passCriteria: '', reviewRecords: [], devEntryNote: '' }
        },
        form3: {
          linkedProjectId: '', linkedPrdVersion: '', linkedTddVersion: '', devStatus: '待开发',
          moduleOverview: { coreGoal: '', preDeps: '', postImpact: '', funcAcceptance: '', nonFuncAcceptance: '', owner: '', plannedCycle: '' },
          featureDevSpecs: [],
          techConstraints: { techStack: '', architecture: '', security: '', performance: '', compatibility: '', logging: '', documentation: '' },
          delivery: { checklist: '', commitGate: '', exitCriteria: '', defectFixRule: '' },
          progress: { taskBreakdown: '', risks: '', updates: [] }
        },
        form4: {
          linkedProjectId: '', riskStatus: '风险识别中',
          risks: [], mitigations: [],
          riskRules: { high: '', medium: '', low: '', changeRisk: '', acceptRule: '' },
          emergencyPlans: [],
          tracking: { cycle: '', stats: '', retrospective: '', improvements: '' }
        },
        form5: {
          linkedProjectId: '', acceptanceStatus: '待启动',
          phaseAcceptance: [], specialAcceptance: [],
          defectRules: { grading: '', fixRule: '', vetoItems: '', legacyRule: '' },
          reviewRecords: [],
          archive: { deliveryChecklist: '', archiveReq: '', conclusion: '', signOff: '', status: '待归档' }
        },
        form6: {
          linkedProjectId: '', outputStatus: '配置中',
          globalConfig: { language: '中文', branding: '', versionRule: '', securityLevel: '', effectiveDate: '', headerFooter: '', globalDisabled: '' },
          stageOutput: [], formatConfig: [], aiTemplates: [], channels: [],
          archiveConfig: { rules: '', path: '', checklist: '', rollbackRule: '' }
        }
      }
    };
  }

  getProjectTypeOptions() {
    return { success: true, message: '获取项目类型选项成功', data: ['web-frontend', 'web-backend', 'mobile-app', 'desktop-app', 'cli-tool', 'library', 'api', 'database', 'devops', 'vscode-extension', 'other'] };
  }

  getTargetAIOptions() {
    return { success: true, message: '获取 AI 助手选项成功', data: ['Trae CN', '豆包', 'DeepSeek', 'GPT', 'Claude', 'Cursor', 'Copilot', '本地模型'] };
  }

  getRequiredFields() {
    return {
      success: true, message: '获取必填字段清单成功',
      data: {
        form0: ['projectName', 'coreGoal', 'coreValue', 'targetUsers', 'deliverables', 'hostEnv', 'techStackConstraint', 'complianceDomain', 'dataPolicy', 'licenseReq', 'perfBaseline', 'startDate', 'launchDate', 'milestones', 'productOwner', 'techOwner', 'testOwner', 'changeApproval'],
        form1: ['userRoles', 'scenarios', 'userStories', 'modules', 'features', 'nonFunctional', 'changeControl', 'review'],
        form2: ['moduleAcceptance', 'testCases', 'nonFuncCases', 'testEnv', 'defectRules', 'review'],
        form3: ['moduleOverview', 'featureDevSpecs', 'techConstraints', 'delivery'],
        form4: ['risks', 'mitigations', 'riskRules', 'emergencyPlans'],
        form5: ['phaseAcceptance', 'specialAcceptance', 'defectRules', 'reviewRecords'],
        form6: ['globalConfig', 'stageOutput', 'formatConfig']
      }
    };
  }

  validateForm(data) {
    const errors = [];
    if (!data.form0 || !data.form0.projectName) errors.push('表单0：项目名称必填');
    if (!data.form0 || !data.form0.coreGoal) errors.push('表单0：核心目标必填');
    if (!data.form0 || !data.form0.hostEnv) errors.push('表单0：目标宿主环境必填');
    if (!data.form0 || !data.form0.techStackConstraint) errors.push('表单0：技术栈硬约束必填');
    return { success: true, message: '表单校验完成', data: { isValid: errors.length === 0, errors } };
  }

  updateForm(currentData, updates) {
    try {
      const updatedData = { ...currentData };
      for (const key of ['form0', 'form1', 'form2', 'form3', 'form4', 'form5', 'form6']) {
        if (updates[key]) updatedData[key] = { ...(currentData[key] || {}), ...(updates[key] || {}) };
      }
      return { success: true, message: '表单数据更新成功', data: updatedData };
    } catch (error) {
      return { success: false, message: '表单数据更新失败', error: error.message || '未知错误' };
    }
  }
}

module.exports = FlowPromptFormSkill;

import { FlowPromptData, SkillResponse } from '../../../shared/src/types';

export class FlowPromptFormSkill {
  /**
   * 获取空的表单数据结构
   */
  public getEmptyForm(): FlowPromptData {
    return {
      targetAI: 'Trae CN',
      step1: {
        projectType: '',
        techStack: [],
        problemDescription: ''
      },
      step2: {
        attempts: []
      },
      step3: {
        coreProblem: '',
        constraints: []
      },
      step4: {
        acceptanceCriteria: []
      },
      step5: {
        functionalBoundaries: '',
        technicalBoundaries: '',
        excludedFeatures: []
      }
    };
  }

  /**
   * 获取项目类型选项
   */
  public getProjectTypeOptions(): string[] {
    return [
      'web-frontend',
      'web-backend',
      'mobile-app',
      'desktop-app',
      'cli-tool',
      'library',
      'api',
      'database',
      'devops',
      'other'
    ];
  }

  /**
   * 获取目标 AI 助手选项
   */
  public getTargetAIOptions(): string[] {
    return [
      'Trae CN',
      'Copilot',
      'Cursor',
      '本地模型'
    ];
  }

  /**
   * 验证表单数据
   */
  public validateForm(data: FlowPromptData): SkillResponse<{ isValid: boolean; errors: string[] }> {
    const errors: string[] = [];

    if (!data.targetAI) {
      errors.push('未选择目标 AI 助手');
    }

    if (!data.step1.projectType) {
      errors.push('项目类型必填');
    }

    if (!data.step1.problemDescription || data.step1.problemDescription.trim().length < 20) {
      errors.push('问题描述至少 20 个字符');
    }

    if (!data.step3.coreProblem || data.step3.coreProblem.trim().length < 10) {
      errors.push('核心问题至少 10 个字符');
    }

    return {
      success: true,
      message: '表单验证完成',
      data: {
        isValid: errors.length === 0,
        errors
      }
    };
  }

  /**
   * 更新表单数据
   */
  public updateForm(currentData: FlowPromptData, updates: Partial<FlowPromptData>): SkillResponse<FlowPromptData> {
    try {
      const updatedData = {
        ...currentData,
        ...updates,
        step1: { ...currentData.step1, ...updates.step1 },
        step2: { ...currentData.step2, ...updates.step2 },
        step3: { ...currentData.step3, ...updates.step3 },
        step4: { ...currentData.step4, ...updates.step4 },
        step5: { ...currentData.step5, ...updates.step5 }
      };

      return {
        success: true,
        message: '表单数据更新成功',
        data: updatedData
      };
    } catch (error) {
      return {
        success: false,
        message: '表单数据更新失败',
        error: error instanceof Error ? error.message : '未知错误'
      };
    }
  }

  /**
   * 添加试错记录
   */
  public addAttempt(currentData: FlowPromptData, attempt: { description: string; result: 'success' | 'failure'; logs: string }): SkillResponse<FlowPromptData> {
    try {
      const newAttempt = {
        id: `attempt_${Date.now()}`,
        ...attempt
      };

      const updatedData = {
        ...currentData,
        step2: {
          ...currentData.step2,
          attempts: [...(currentData.step2.attempts || []), newAttempt]
        }
      };

      return {
        success: true,
        message: '试错记录添加成功',
        data: updatedData
      };
    } catch (error) {
      return {
        success: false,
        message: '试错记录添加失败',
        error: error instanceof Error ? error.message : '未知错误'
      };
    }
  }

  /**
   * 添加验收标准
   */
  public addCriteria(currentData: FlowPromptData, criteria: { description: string; metric: string; targetValue: string }): SkillResponse<FlowPromptData> {
    try {
      const updatedData = {
        ...currentData,
        step4: {
          ...currentData.step4,
          acceptanceCriteria: [...(currentData.step4.acceptanceCriteria || []), criteria]
        }
      };

      return {
        success: true,
        message: '验收标准添加成功',
        data: updatedData
      };
    } catch (error) {
      return {
        success: false,
        message: '验收标准添加失败',
        error: error instanceof Error ? error.message : '未知错误'
      };
    }
  }
}

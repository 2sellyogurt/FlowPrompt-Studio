import { FlowPromptData, Draft, SkillResponse } from '../../../shared/src/types';
import * as fs from 'fs';
import * as path from 'path';

export class FlowPromptDraftSkill {
  private draftsDir: string;

  constructor() {
    // 创建草稿存储目录
    this.draftsDir = path.join(process.cwd(), '.flowprompt', 'drafts');
    this.ensureDraftsDirExists();
  }

  /**
   * 确保草稿目录存在
   */
  private ensureDraftsDirExists(): void {
    if (!fs.existsSync(this.draftsDir)) {
      fs.mkdirSync(this.draftsDir, { recursive: true });
    }
  }

  /**
   * 生成唯一 ID
   */
  private generateId(): string {
    return `draft_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
  }

  /**
   * 保存草稿
   */
  public saveDraft(name: string, formData: FlowPromptData): SkillResponse<Draft> {
    try {
      const draft: Draft = {
        id: this.generateId(),
        name: name || `草稿_${new Date().toLocaleString('zh-CN')}`,
        formData,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      };

      const draftPath = path.join(this.draftsDir, `${draft.id}.json`);
      fs.writeFileSync(draftPath, JSON.stringify(draft, null, 2));

      return {
        success: true,
        message: '草稿保存成功',
        data: draft
      };
    } catch (error) {
      return {
        success: false,
        message: '草稿保存失败',
        error: error instanceof Error ? error.message : '未知错误'
      };
    }
  }

  /**
   * 获取草稿列表
   */
  public getDraftList(): SkillResponse<Draft[]> {
    try {
      const files = fs.readdirSync(this.draftsDir).filter(file => file.endsWith('.json'));
      const drafts: Draft[] = [];

      for (const file of files) {
        const draftPath = path.join(this.draftsDir, file);
        const content = fs.readFileSync(draftPath, 'utf8');
        const draft = JSON.parse(content) as Draft;
        drafts.push(draft);
      }

      // 按更新时间排序
      drafts.sort((a, b) => new Date(b.updatedAt).getTime() - new Date(a.updatedAt).getTime());

      return {
        success: true,
        message: '获取草稿列表成功',
        data: drafts
      };
    } catch (error) {
      return {
        success: false,
        message: '获取草稿列表失败',
        error: error instanceof Error ? error.message : '未知错误'
      };
    }
  }

  /**
   * 获取单个草稿
   */
  public getDraft(id: string): SkillResponse<Draft> {
    try {
      const draftPath = path.join(this.draftsDir, `${id}.json`);
      
      if (!fs.existsSync(draftPath)) {
        return {
          success: false,
          message: '草稿不存在',
          error: '草稿 ID 不存在'
        };
      }

      const content = fs.readFileSync(draftPath, 'utf8');
      const draft = JSON.parse(content) as Draft;

      return {
        success: true,
        message: '获取草稿成功',
        data: draft
      };
    } catch (error) {
      return {
        success: false,
        message: '获取草稿失败',
        error: error instanceof Error ? error.message : '未知错误'
      };
    }
  }

  /**
   * 获取最新的草稿
   */
  public getLatestDraft(): SkillResponse<Draft | null> {
    try {
      const draftList = this.getDraftList();
      
      if (!draftList.success || !draftList.data || draftList.data.length === 0) {
        return {
          success: true,
          message: '没有找到草稿',
          data: null
        };
      }

      return {
        success: true,
        message: '获取最新草稿成功',
        data: draftList.data[0]
      };
    } catch (error) {
      return {
        success: false,
        message: '获取最新草稿失败',
        error: error instanceof Error ? error.message : '未知错误'
      };
    }
  }

  /**
   * 更新草稿
   */
  public updateDraft(id: string, updates: { name?: string; formData?: FlowPromptData }): SkillResponse<Draft> {
    try {
      const draftPath = path.join(this.draftsDir, `${id}.json`);
      
      if (!fs.existsSync(draftPath)) {
        return {
          success: false,
          message: '草稿不存在',
          error: '草稿 ID 不存在'
        };
      }

      const content = fs.readFileSync(draftPath, 'utf8');
      const draft = JSON.parse(content) as Draft;

      // 更新字段
      if (updates.name) {
        draft.name = updates.name;
      }
      if (updates.formData) {
        draft.formData = updates.formData;
      }
      draft.updatedAt = new Date().toISOString();

      fs.writeFileSync(draftPath, JSON.stringify(draft, null, 2));

      return {
        success: true,
        message: '草稿更新成功',
        data: draft
      };
    } catch (error) {
      return {
        success: false,
        message: '草稿更新失败',
        error: error instanceof Error ? error.message : '未知错误'
      };
    }
  }

  /**
   * 删除草稿
   */
  public deleteDraft(id: string): SkillResponse<{ success: boolean }> {
    try {
      const draftPath = path.join(this.draftsDir, `${id}.json`);
      
      if (!fs.existsSync(draftPath)) {
        return {
          success: false,
          message: '草稿不存在',
          error: '草稿 ID 不存在'
        };
      }

      fs.unlinkSync(draftPath);

      return {
        success: true,
        message: '草稿删除成功',
        data: { success: true }
      };
    } catch (error) {
      return {
        success: false,
        message: '草稿删除失败',
        error: error instanceof Error ? error.message : '未知错误'
      };
    }
  }

  /**
   * 清空所有草稿
   */
  public clearAllDrafts(): SkillResponse<{ success: boolean; deletedCount: number }> {
    try {
      const files = fs.readdirSync(this.draftsDir).filter(file => file.endsWith('.json'));
      let deletedCount = 0;

      for (const file of files) {
        const draftPath = path.join(this.draftsDir, file);
        fs.unlinkSync(draftPath);
        deletedCount++;
      }

      return {
        success: true,
        message: `已清空所有草稿（共删除 ${deletedCount} 个）`,
        data: { success: true, deletedCount }
      };
    } catch (error) {
      return {
        success: false,
        message: '清空草稿失败',
        error: error instanceof Error ? error.message : '未知错误'
      };
    }
  }
}

/**
 * FlowPrompt Studio - 全链路工程化AI开发技能集
 * Copyright (C) 2026 FlowPrompt Studio Team
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Affero General Public License as published
 * by the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU Affero General Public License for more details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program. If not, see <https://www.gnu.org/licenses/>.
 */

// FlowPrompt-Draft 技能的 JavaScript 实现
class FlowPromptDraftSkill {
  constructor() {
    // 使用内存存储，避免文件系统权限问题
    this.drafts = [];
  }

  /**
   * 生成唯一 ID
   */
  generateId() {
    return `draft_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
  }

  /**
   * 保存草稿
   */
  saveDraft(name, formData) {
    try {
      const draft = {
        id: this.generateId(),
        name: name || `草稿_${new Date().toLocaleString('zh-CN')}`,
        formData,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      };

      this.drafts.push(draft);

      return {
        success: true,
        message: '草稿保存成功',
        data: draft
      };
    } catch (error) {
      return {
        success: false,
        message: '草稿保存失败',
        error: error.message || '未知错误'
      };
    }
  }

  /**
   * 获取草稿列表
   */
  getDraftList() {
    try {
      // 按更新时间排序
      const sortedDrafts = [...this.drafts].sort((a, b) => new Date(b.updatedAt).getTime() - new Date(a.updatedAt).getTime());

      return {
        success: true,
        message: '获取草稿列表成功',
        data: sortedDrafts
      };
    } catch (error) {
      return {
        success: false,
        message: '获取草稿列表失败',
        error: error.message || '未知错误'
      };
    }
  }

  /**
   * 获取单个草稿
   */
  getDraft(id) {
    try {
      const draft = this.drafts.find(d => d.id === id);
      
      if (!draft) {
        return {
          success: false,
          message: '草稿不存在',
          error: '草稿 ID 不存在'
        };
      }

      return {
        success: true,
        message: '获取草稿成功',
        data: draft
      };
    } catch (error) {
      return {
        success: false,
        message: '获取草稿失败',
        error: error.message || '未知错误'
      };
    }
  }

  /**
   * 获取最新的草稿
   */
  getLatestDraft() {
    try {
      const draftList = this.getDraftList();
      
      if (!draftList.success || !draftList.data || draftList.data.length === 0) {
        return {
          success: true,
          message: '没有找到草稿',
          data: null
        };
      }

      return {
        success: true,
        message: '获取最新草稿成功',
        data: draftList.data[0]
      };
    } catch (error) {
      return {
        success: false,
        message: '获取最新草稿失败',
        error: error.message || '未知错误'
      };
    }
  }

  /**
   * 更新草稿
   */
  updateDraft(id, updates) {
    try {
      const index = this.drafts.findIndex(d => d.id === id);
      
      if (index === -1) {
        return {
          success: false,
          message: '草稿不存在',
          error: '草稿 ID 不存在'
        };
      }

      const draft = { ...this.drafts[index] };

      // 更新字段
      if (updates.name) {
        draft.name = updates.name;
      }
      if (updates.formData) {
        draft.formData = updates.formData;
      }
      draft.updatedAt = new Date().toISOString();

      this.drafts[index] = draft;

      return {
        success: true,
        message: '草稿更新成功',
        data: draft
      };
    } catch (error) {
      return {
        success: false,
        message: '草稿更新失败',
        error: error.message || '未知错误'
      };
    }
  }

  /**
   * 删除草稿
   */
  deleteDraft(id) {
    try {
      const index = this.drafts.findIndex(d => d.id === id);
      
      if (index === -1) {
        return {
          success: false,
          message: '草稿不存在',
          error: '草稿 ID 不存在'
        };
      }

      this.drafts.splice(index, 1);

      return {
        success: true,
        message: '草稿删除成功',
        data: { success: true }
      };
    } catch (error) {
      return {
        success: false,
        message: '草稿删除失败',
        error: error.message || '未知错误'
      };
    }
  }

  /**
   * 清空所有草稿
   */
  clearAllDrafts() {
    try {
      const deletedCount = this.drafts.length;
      this.drafts = [];

      return {
        success: true,
        message: `已清空所有草稿（共删除 ${deletedCount} 个）`,
        data: { success: true, deletedCount }
      };
    } catch (error) {
      return {
        success: false,
        message: '清空草稿失败',
        error: error.message || '未知错误'
      };
    }
  }
}

module.exports = FlowPromptDraftSkill;

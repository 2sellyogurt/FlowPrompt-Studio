/**
 * FlowPrompt Studio - 全链路工程化AI开发技能集
 * Copyright (C) 2026 FlowPrompt Studio Team
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Affero General Public License as published
 * by the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU Affero General Public License for more details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program. If not, see <https://www.gnu.org/licenses/>.
 */

// FlowPrompt-Validator 技能入口
const FlowPromptValidatorSkill = require('./src/validatorSkill.js');

class FlowPromptValidator {
  constructor() {
    this.skill = new FlowPromptValidatorSkill();
  }

  async run(inputs) {
    try {
      const { action, data } = inputs;

      switch (action) {
        case 'validate':
          return this.skill.validate(data);
        case 'generateSummary':
          return this.skill.generateSummary(data);
        case 'canGeneratePrompt':
          return this.skill.canGeneratePrompt(data);
        default:
          throw new Error(`未知操作: ${action}`);
      }
    } catch (error) {
      return {
        success: false,
        message: '操作失败',
        error: error.message
      };
    }
  }
}

module.exports = FlowPromptValidator;

/**
 * FlowPrompt Studio - 全链路工程化AI开发技能集
 * Copyright (C) 2026 FlowPrompt Studio Team
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Affero General Public License as published
 * by the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU Affero General Public License for more details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program. If not, see <https://www.gnu.org/licenses/>.
 */

// FlowPrompt-Validator 技能 v3.0
// 基于"6表单全链路工程化AI开发体系"重构
// 评分规则：准入准出 + 一票否决 + 分阶段权重

const FormState = { EMPTY: 'empty', FILLING: 'filling', VALIDATING: 'validating', VALID: 'valid', EXCELLENT: 'excellent', SAVED: 'saved', SENT_TO_TRAE: 'sent_to_trae' };

const VETO_ITEMS = [
  { id: 'V1', check: (d) => !d.form0?.projectName, msg: '表单0：项目名称未填写' },
  { id: 'V2', check: (d) => !d.form0?.coreGoal, msg: '表单0：核心目标未定义' },
  { id: 'V3', check: (d) => !d.form0?.techStackConstraint, msg: '表单0：技术栈硬约束未设定（AI生成不可突破红线）' },
  { id: 'V4', check: (d) => !d.form0?.hostEnv, msg: '表单0：目标宿主环境未指定' },
  { id: 'V5', check: (d) => !d.form0?.complianceDomain, msg: '表单0：合规域要求未明确' },
  { id: 'V6', check: (d) => !d.form0?.dataPolicy, msg: '表单0：数据主权策略未设定' }
];

class FlowPromptValidatorSkill {
  validate(formData) {
    try {
      const errors = [];
      const warnings = [];
      const vetoTriggered = [];
      for (const veto of VETO_ITEMS) {
        if (veto.check(formData)) { vetoTriggered.push(veto.msg); errors.push(veto.msg); }
      }
      const hasVeto = vetoTriggered.length > 0;
      const stageScores = {
        form0: { max: 30, earned: 0, label: '表单0·核心基础信息' },
        form1: { max: 25, earned: 0, label: '表单1·PRD需求定义' },
        form2: { max: 15, earned: 0, label: '表单2·TDD测试定义' },
        form3: { max: 10, earned: 0, label: '表单3·模块开发要求' },
        form4: { max: 10, earned: 0, label: '表单4·风险矩阵管控' },
        form5: { max: 10, earned: 0, label: '表单5·验收标准' }
      };
      const f0 = formData.form0 || {};
      if (f0.projectName) stageScores.form0.earned += 3;
      if (f0.coreGoal && f0.coreGoal.trim().length >= 10) stageScores.form0.earned += 5;
      if (f0.coreValue && f0.coreValue.length > 0) stageScores.form0.earned += 3;
      if (f0.targetUsers) stageScores.form0.earned += 2;
      if (f0.deliverables && f0.deliverables.length > 0) stageScores.form0.earned += 2;
      if (f0.hostEnv) stageScores.form0.earned += 2; else warnings.push('表单0：目标宿主环境未设定（硬约束红线）');
      if (f0.techStackConstraint) stageScores.form0.earned += 2; else warnings.push('表单0：技术栈硬约束未设定（硬约束红线）');
      if (f0.complianceDomain) stageScores.form0.earned += 2;
      if (f0.dataPolicy) stageScores.form0.earned += 2;
      if (f0.licenseReq) stageScores.form0.earned += 2;
      if (f0.perfBaseline) stageScores.form0.earned += 2; else warnings.push('表单0：性能基线未设定');
      if (f0.startDate && f0.launchDate) stageScores.form0.earned += 2;
      if (f0.productOwner && f0.techOwner) stageScores.form0.earned += 2;
      if (f0.testOwner) stageScores.form0.earned += 1;
      if (f0.changeApproval) stageScores.form0.earned += 2;
      const f1 = formData.form1 || {};
      if (f1.userRoles && f1.userRoles.length > 0) { stageScores.form1.earned += 5; if (f1.userRoles.length >= 2) stageScores.form1.earned += 3; } else warnings.push('表单1：建议定义至少2个用户角色（+8分）');
      if (f1.scenarios && f1.scenarios.length > 0) { stageScores.form1.earned += 4; if (f1.scenarios.length >= 3) stageScores.form1.earned += 2; } else warnings.push('表单1：建议定义核心使用场景（+6分）');
      if (f1.userStories && f1.userStories.length > 0) { stageScores.form1.earned += 3; if (f1.userStories.length >= 5) stageScores.form1.earned += 2; }
      if (f1.modules && f1.modules.length > 0) { stageScores.form1.earned += 3; if (f1.features && f1.features.length > 0) stageScores.form1.earned += 3; } else warnings.push('表单1：建议定义功能模块和功能点（+6分）');
      const nf = f1.nonFunctional || {};
      const nfFilled = Object.values(nf).filter(v => v && v.trim().length > 0).length;
      if (nfFilled >= 3) stageScores.form1.earned += 3; else if (nfFilled > 0) stageScores.form1.earned += 1; else warnings.push('表单1：建议填写非功能需求（+3分）');
      const f2 = formData.form2 || {};
      if (f2.moduleAcceptance && f2.moduleAcceptance.length > 0) stageScores.form2.earned += 3; else warnings.push('表单2：建议定义分模块验收标准（+3分）');
      if (f2.testCases && f2.testCases.length > 0) { stageScores.form2.earned += 5; if (f2.testCases.length >= 5) stageScores.form2.earned += 2; } else warnings.push('表单2：强烈建议编写功能测试用例（+7分）');
      if (f2.nonFuncCases && f2.nonFuncCases.length > 0) stageScores.form2.earned += 3;
      if (f2.defectRules && f2.defectRules.grading) stageScores.form2.earned += 2;
      const f3 = formData.form3 || {};
      const mo = f3.moduleOverview || {};
      if (mo.coreGoal) stageScores.form3.earned += 2;
      if (f3.featureDevSpecs && f3.featureDevSpecs.length > 0) { stageScores.form3.earned += 4; if (f3.featureDevSpecs.length >= 3) stageScores.form3.earned += 2; } else warnings.push('表单3：建议定义功能点开发规格（+6分）');
      const tc = f3.techConstraints || {};
      if (tc.techStack || tc.architecture) stageScores.form3.earned += 2;
      const f4 = formData.form4 || {};
      if (f4.risks && f4.risks.length > 0) { stageScores.form4.earned += 4; if (f4.mitigations && f4.mitigations.length > 0) stageScores.form4.earned += 3; } else warnings.push('表单4：建议进行风险识别（+7分）');
      if (f4.riskRules && (f4.riskRules.high || f4.riskRules.medium)) stageScores.form4.earned += 2;
      if (f4.emergencyPlans && f4.emergencyPlans.length > 0) stageScores.form4.earned += 1;
      const f5 = formData.form5 || {};
      if (f5.phaseAcceptance && f5.phaseAcceptance.length > 0) { stageScores.form5.earned += 4; if (f5.phaseAcceptance.length >= 3) stageScores.form5.earned += 2; } else warnings.push('表单5：建议定义分阶段验收项（+6分）');
      if (f5.specialAcceptance && f5.specialAcceptance.length > 0) stageScores.form5.earned += 2;
      if (f5.defectRules && f5.defectRules.vetoItems) stageScores.form5.earned += 2;
      let outputBonus = 0;
      const f6 = formData.form6 || {};
      if (f6.globalConfig && f6.globalConfig.language) outputBonus += 1;
      if (f6.stageOutput && f6.stageOutput.length > 0) outputBonus += 2;
      if (f6.formatConfig && f6.formatConfig.length > 0) outputBonus += 2;
      const baseScore = Object.values(stageScores).reduce((s, p) => s + Math.min(p.earned, p.max), 0);
      let score = Math.min(100, Math.max(0, baseScore + outputBonus));
      let state;
      if (hasVeto) state = FormState.FILLING;
      else if (score >= 85) state = FormState.EXCELLENT;
      else if (score >= 60) state = FormState.VALID;
      else state = FormState.FILLING;
      return { success: true, message: hasVeto ? '存在一票否决项，无法生成' : '表单验证完成', data: { isValid: !hasVeto && errors.length === 0, hasVeto, vetoTriggered, score, stageScores, outputBonus, errors, warnings, state } };
    } catch (error) { return { success: false, message: '验证失败', error: error.message || '未知错误' }; }
  }

  generateSummary(vr) {
    try {
      const st = this.getStateText(vr.state);
      const sl = Object.values(vr.stageScores || {}).map(s => `  - ${s.label}: ${s.earned}/${s.max}分`).join('\n');
      let vl = '';
      if (vr.vetoTriggered?.length > 0) vl = '\n**一票否决项触发**:\n' + vr.vetoTriggered.map(v => `  - ${v}`).join('\n');
      let bl = vr.outputBonus > 0 ? `\n**输出配置加分**: +${vr.outputBonus}分` : '';
      return { success: true, message: '摘要生成成功', data: `**全链路表单质量评分**: ${vr.score}/100\n**状态**: ${st}\n\n**分阶段得分**:\n${sl}${bl}${vl}\n\n**必填项**: ${vr.errors.length === 0 ? '已完成' : '还有' + vr.errors.length + '项未填写'}\n**建议项**: ${vr.warnings.length > 0 ? '有' + vr.warnings.length + '项建议优化' : '所有建议项已完成'}` };
    } catch (e) { return { success: false, message: '摘要生成失败', error: e.message }; }
  }

  getStateText(s) { return {empty:'空表单',filling:'填写中',validating:'校验中',valid:'校验通过',excellent:'优秀',saved:'已保存',sent_to_trae:'已发送'}[s] || '未知'; }

  canGeneratePrompt(vr) {
    try {
      if (vr.hasVeto) return { success: true, message: '存在一票否决项', data: { canGenerate: false, reason: '触发了一票否决项：' + vr.vetoTriggered.join('；') } };
      if (!vr.isValid) return { success: true, message: '表单未通过验证', data: { canGenerate: false, reason: '还有 ' + vr.errors.length + ' 项必填内容未完成' } };
      if (vr.score < 60) return { success: true, message: '表单质量评分过低', data: { canGenerate: false, reason: '当前评分 ' + vr.score + ' 分，建议优化至 60 分以上' } };
      return { success: true, message: '可以生成 Prompt', data: { canGenerate: true, score: vr.score } };
    } catch (e) { return { success: false, message: '检查失败', error: e.message }; }
  }
}

module.exports = FlowPromptValidatorSkill;

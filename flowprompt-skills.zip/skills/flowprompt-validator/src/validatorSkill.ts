import { FlowPromptData, FormValidationResult, FormState, SkillResponse } from '../../../shared/src/types';

export class FlowPromptValidatorSkill {
  /**
   * 验证表单数据并计算质量评分
   */
  public validate(formData: FlowPromptData): SkillResponse<FormValidationResult> {
    try {
      const errors: string[] = [];
      const warnings: string[] = [];
      let score = 0;

      // 验证目标 AI 助手
      if (!formData.targetAI) {
        errors.push('未选择目标 AI 助手');
      } else {
        score += 5;
      }

      // 验证步骤 1：问题上下文
      if (!formData.step1.projectType) {
        errors.push('步骤 1：项目类型必填');
      } else {
        score += 10;
      }

      if (!formData.step1.problemDescription || formData.step1.problemDescription.trim().length < 20) {
        errors.push('步骤 1：问题描述至少 20 个字符');
      } else {
        score += 15;
        
        if (formData.step1.problemDescription.length > 100) {
          score += 5;
        }
      }

      if (formData.step1.techStack && formData.step1.techStack.length > 0) {
        score += 5;
      } else {
        warnings.push('步骤 1：建议添加技术栈标签');
      }

      // 验证步骤 2：试错记录
      if (formData.step2.attempts && formData.step2.attempts.length > 0) {
        score += 15;
        
        const attemptsWithLogs = formData.step2.attempts.filter((a) => a.logs && a.logs.length > 0);
        if (attemptsWithLogs.length > 0) {
          score += 5;
        }
      } else {
        warnings.push('步骤 2：强烈建议记录试错过程');
      }

      // 验证步骤 3：核心问题定义
      if (!formData.step3.coreProblem || formData.step3.coreProblem.trim().length < 10) {
        errors.push('步骤 3：核心问题至少 10 个字符');
      } else {
        score += 20;
        
        if (formData.step3.constraints && formData.step3.constraints.length > 0) {
          score += 5;
        }
      }

      // 验证步骤 4：验收标准
      if (formData.step4.acceptanceCriteria && formData.step4.acceptanceCriteria.length > 0) {
        score += 15;
        
        const quantified = formData.step4.acceptanceCriteria.filter((c) => 
          c.metric && c.targetValue
        );
        if (quantified.length > 0) {
          score += 10;
        }
      } else {
        warnings.push('步骤 4：建议添加量化验收标准');
      }

      // 验证步骤 5：功能/技术边界
      if (formData.step5.functionalBoundaries || formData.step5.technicalBoundaries) {
        score += 10;
      } else {
        warnings.push('步骤 5：建议明确功能/技术边界');
      }

      if (formData.step5.excludedFeatures && formData.step5.excludedFeatures.length > 0) {
        score += 5;
      }

      // 确定表单状态
      let state: FormState;
      if (errors.length > 0) {
        state = FormState.FILLING;
      } else if (score >= 80) {
        state = FormState.EXCELLENT;
      } else if (score >= 60) {
        state = FormState.VALID;
      } else {
        state = FormState.FILLING;
      }

      const validationResult: FormValidationResult = {
        isValid: errors.length === 0,
        score: Math.min(100, score),
        errors,
        warnings,
        state
      };

      return {
        success: true,
        message: '表单验证完成',
        data: validationResult
      };
    } catch (error) {
      return {
        success: false,
        message: '验证失败',
        error: error instanceof Error ? error.message : '未知错误'
      };
    }
  }

  /**
   * 生成验证摘要
   */
  public generateSummary(validationResult: FormValidationResult): SkillResponse<string> {
    try {
      const stateText = this.getStateText(validationResult.state);
      
      const summary = `**Prompt 质量评分**: ${validationResult.score}/100
` +
        `**状态**: ${stateText}
` +
        `**必填项**: ${validationResult.errors.length === 0 ? '✅ 已完成' : `❌ 还有${validationResult.errors.length}项未填写`}
` +
        `**建议项**: ${validationResult.warnings.length > 0 ? `⚠️ 有${validationResult.warnings.length}项建议优化` : '✅ 所有建议项已完成'}`;

      return {
        success: true,
        message: '摘要生成成功',
        data: summary
      };
    } catch (error) {
      return {
        success: false,
        message: '摘要生成失败',
        error: error instanceof Error ? error.message : '未知错误'
      };
    }
  }

  /**
   * 获取状态文本
   */
  private getStateText(state: FormState): string {
    switch (state) {
      case FormState.EMPTY:
        return '空表单';
      case FormState.FILLING:
        return '填写中';
      case FormState.VALIDATING:
        return '校验中';
      case FormState.VALID:
        return '✅ 校验通过';
      case FormState.EXCELLENT:
        return '🌟 优秀';
      case FormState.SAVED:
        return '💾 已保存';
      case FormState.SENT_TO_TRAE:
        return '📤 已发送';
      default:
        return '未知';
    }
  }

  /**
   * 检查表单是否可以生成 Prompt
   */
  public canGeneratePrompt(validationResult: FormValidationResult): SkillResponse<{ canGenerate: boolean; reason?: string }> {
    try {
      if (!validationResult.isValid) {
        return {
          success: true,
          message: '表单未通过验证',
          data: {
            canGenerate: false,
            reason: `还有 ${validationResult.errors.length} 项必填内容未完成`
          }
        };
      }

      if (validationResult.score < 60) {
        return {
          success: true,
          message: '表单质量评分过低',
          data: {
            canGenerate: false,
            reason: '表单质量评分低于 60 分，建议优化后再生成'
          }
        };
      }

      return {
        success: true,
        message: '可以生成 Prompt',
        data: {
          canGenerate: true
        }
      };
    } catch (error) {
      return {
        success: false,
        message: '检查失败',
        error: error instanceof Error ? error.message : '未知错误'
      };
    }
  }
}

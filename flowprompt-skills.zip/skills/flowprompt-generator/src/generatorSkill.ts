import { FlowPromptData, SkillResponse } from '../../../shared/src/types';

export class FlowPromptGeneratorSkill {
  /**
   * 生成标准化的 Prompt
   */
  public generate(formData: FlowPromptData): SkillResponse<string> {
    try {
      const sections: string[] = [];

      sections.push(this.generateHeader(formData));
      sections.push(this.generateContext(formData.step1));
      sections.push(this.generateAttempts(formData.step2));
      sections.push(this.generateCoreProblem(formData.step3));
      sections.push(this.generateAcceptanceCriteria(formData.step4));
      sections.push(this.generateBoundaries(formData.step5));
      sections.push(this.generateFooter());

      const prompt = sections.join('\n\n');

      return {
        success: true,
        message: 'Prompt 生成成功',
        data: prompt
      };
    } catch (error) {
      return {
        success: false,
        message: 'Prompt 生成失败',
        error: error instanceof Error ? error.message : '未知错误'
      };
    }
  }

  /**
   * 生成 Prompt 头部
   */
  private generateHeader(formData: FlowPromptData): string {
    return `# 工程化问题请求
**目标 AI 助手**: ${formData.targetAI}
**生成时间**: ${new Date().toLocaleString('zh-CN')}
**FlowPrompt Studio 版本**: 1.0.0`;
  }

  /**
   * 生成问题上下文部分
   */
  private generateContext(step1: any): string {
    const techStackStr = step1.techStack && step1.techStack.length > 0 
      ? step1.techStack.join(', ') 
      : '未指定';

    return `## 1. 问题上下文
**项目类型**: ${step1.projectType || '未指定'}
**技术栈**: ${techStackStr}

**问题描述**:
${step1.problemDescription || '未提供详细描述'}`;
  }

  /**
   * 生成试错记录部分
   */
  private generateAttempts(step2: any): string {
    if (!step2.attempts || step2.attempts.length === 0) {
      return `## 2. 试错记录
⚠️ 暂无试错记录（强烈建议记录已尝试的方案，帮助 AI 更好理解问题）`;
    }

    const attemptsStr = step2.attempts.map((attempt: any, index: number) => {
      const status = attempt.result === 'success' ? '✅ 成功' : '❌ 失败';
      return `### 尝试 ${index + 1}
**方案描述**: ${attempt.description || '未描述'}
**结果**: ${status}
**日志/报错**:
\`\`\`
${attempt.logs || '无日志'}
\`\`\``;
    }).join('\n\n');

    return `## 2. 试错记录

${attemptsStr}`;
  }

  /**
   * 生成核心问题定义部分
   */
  private generateCoreProblem(step3: any): string {
    const constraintsStr = step3.constraints && step3.constraints.length > 0
      ? step3.constraints.map((c: string) => `- ${c}`).join('\n')
      : '无特殊约束';

    return `## 3. 核心问题定义
**核心问题**:
${step3.coreProblem || '未定义核心问题'}

**约束条件**:
${constraintsStr}`;
  }

  /**
   * 生成验收标准部分
   */
  private generateAcceptanceCriteria(step4: any): string {
    if (!step4.acceptanceCriteria || step4.acceptanceCriteria.length === 0) {
      return `## 4. 验收标准
⚠️ 暂无量化验收标准（建议添加可量化的验收指标）`;
    }

    const criteriaStr = step4.acceptanceCriteria.map((criteria: any, index: number) => {
      return `### 验收项 ${index + 1}
- **描述**: ${criteria.description || '未描述'}
- **指标**: ${criteria.metric || '未指定'}
- **目标值**: ${criteria.targetValue || '未指定'}`;
    }).join('\n\n');

    return `## 4. 验收标准

${criteriaStr}`;
  }

  /**
   * 生成功能/技术边界部分
   */
  private generateBoundaries(step5: any): string {
    const excludedStr = step5.excludedFeatures && step5.excludedFeatures.length > 0
      ? step5.excludedFeatures.map((f: string) => `- ${f}`).join('\n')
      : '无明确排除功能';

    return `## 5. 功能/技术边界
**功能边界**:
${step5.functionalBoundaries || '未指定功能边界'}

**技术边界**:
${step5.technicalBoundaries || '未指定技术边界'}

**明确排除的功能**:
${excludedStr}`;
  }

  /**
   * 生成 Prompt 底部
   */
  private generateFooter(): string {
    return `---
> 此 Prompt 由 FlowPrompt Studio 生成
> 遵循工程化提问最佳实践
> 协议：MIT`;
  }

  /**
   * 生成简短的 Prompt 摘要
   */
  public generateSummary(formData: FlowPromptData): SkillResponse<string> {
    try {
      const summary = `**项目类型**: ${formData.step1.projectType || '未指定'}\n` +
        `**技术栈**: ${formData.step1.techStack && formData.step1.techStack.length > 0 ? formData.step1.techStack.join(', ') : '未指定'}\n` +
        `**核心问题**: ${formData.step3.coreProblem ? formData.step3.coreProblem.substring(0, 50) + (formData.step3.coreProblem.length > 50 ? '...' : '') : '未定义'}\n` +
        `**试错记录**: ${formData.step2.attempts && formData.step2.attempts.length > 0 ? formData.step2.attempts.length + ' 条' : '无'}\n` +
        `**验收标准**: ${formData.step4.acceptanceCriteria && formData.step4.acceptanceCriteria.length > 0 ? formData.step4.acceptanceCriteria.length + ' 项' : '无'}`;

      return {
        success: true,
        message: '摘要生成成功',
        data: summary
      };
    } catch (error) {
      return {
        success: false,
        message: '摘要生成失败',
        error: error instanceof Error ? error.message : '未知错误'
      };
    }
  }

  /**
   * 优化 Prompt（去除冗余信息）
   */
  public optimizePrompt(prompt: string): SkillResponse<string> {
    try {
      // 去除多余的空行
      let optimized = prompt.replace(/\n{3,}/g, '\n\n');
      
      // 去除首尾空格
      optimized = optimized.trim();

      return {
        success: true,
        message: 'Prompt 优化成功',
        data: optimized
      };
    } catch (error) {
      return {
        success: false,
        message: 'Prompt 优化失败',
        error: error instanceof Error ? error.message : '未知错误'
      };
    }
  }
}

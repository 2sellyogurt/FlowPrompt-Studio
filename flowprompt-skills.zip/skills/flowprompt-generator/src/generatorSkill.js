/**
 * FlowPrompt Studio - 全链路工程化AI开发技能集
 * Copyright (C) 2026 FlowPrompt Studio Team
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Affero General Public License as published
 * by the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU Affero General Public License for more details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program. If not, see <https://www.gnu.org/licenses/>.
 */

// FlowPrompt-Generator 技能 v3.0
class FlowPromptGeneratorSkill {
  generate(formData) {
    try {
      const s = [];
      s.push(this.generateHeader(formData));
      s.push(this.generateForm0(formData.form0));
      if (formData.form1) s.push(this.generateForm1(formData.form1));
      if (formData.form2) s.push(this.generateForm2(formData.form2));
      if (formData.form3) s.push(this.generateForm3(formData.form3));
      if (formData.form4) s.push(this.generateForm4(formData.form4));
      if (formData.form5) s.push(this.generateForm5(formData.form5));
      if (formData.form6) s.push(this.generateForm6(formData.form6));
      s.push(this.generateFooter());
      return { success: true, message: 'Prompt 生成成功（7表单全链路体系 v3.0）', data: s.join('\n\n') };
    } catch (e) { return { success: false, message: 'Prompt 生成失败', error: e.message }; }
  }
  generateHeader(fd) { const f0=fd.form0||{}; return `# 全链路工程化AI开发请求\n**项目名称**: ${f0.projectName||'未定义'}\n**项目ID**: ${f0.projectId||'待生成'}\n**生成时间**: ${new Date().toLocaleString('zh-CN')}\n**FlowPrompt Studio 版本**: 3.0.0\n**方法论**: 6表单全链路工程化AI开发体系`; }
  generateForm0(f0) {
    if (!f0) return '<form-0>\n## 表单0：核心基础信息 — 未填写\n</form-0>';
    const v = f0.coreValue?.length > 0 ? f0.coreValue.map(x=>`- ${x}`).join('\n') : '未定义';
    const d = f0.deliverables?.length > 0 ? f0.deliverables.map(x=>`- ${x}`).join('\n') : '未定义';
    return `<form-0>\n## 表单0：核心基础信息（全链路唯一主键）\n\n### 项目定义\n- **项目名称**: ${f0.projectName||'未定义'}\n- **核心目标**: ${f0.coreGoal||'未定义'}\n- **核心价值**: \n${v}\n- **目标用户**: ${f0.targetUsers||'未定义'}\n- **交付物**: \n${d}\n\n### 全链路硬约束（AI生成不可突破红线）\n- **宿主环境**: ${f0.hostEnv||'未设定'}\n- **技术栈约束**: ${f0.techStackConstraint||'未设定'}\n- **合规域**: ${f0.complianceDomain||'未设定'}\n- **数据主权**: ${f0.dataPolicy||'未设定'}\n- **开源许可**: ${f0.licenseReq||'未设定'}\n- **性能基线**: ${f0.perfBaseline||'未设定'}\n\n### 项目周期\n- **启动日期**: ${f0.startDate||'未设定'}\n- **上线日期**: ${f0.launchDate||'未设定'}\n- **里程碑**: ${f0.milestones||'未设定'}\n\n### 责任主体\n- **产品负责人**: ${f0.productOwner||'未指定'}\n- **技术负责人**: ${f0.techOwner||'未指定'}\n- **测试负责人**: ${f0.testOwner||'未指定'}\n- **变更审批**: ${f0.changeApproval||'未指定'}\n\n---\n**硬约束红线**：AI生成的所有代码、方案、建议必须严格遵守上述技术栈约束、合规域要求和数据主权策略，不得突破。\n</form-0>`;
  }
  generateForm1(f1) {
    if (!f1) return '';
    const r = f1.userRoles?.length > 0 ? f1.userRoles.map(x=>`### ${x.name}\n- 痛点: ${x.painPoints||'未描述'}\n- 需求: ${x.needs||'未描述'}`).join('\n\n') : '未定义用户角色';
    const sc = f1.scenarios?.length > 0 ? f1.scenarios.map(x=>`- [${x.priority||'P2'}] ${x.name}: ${x.flow||'未描述流程'}`).join('\n') : '未定义场景';
    const st = f1.userStories?.length > 0 ? f1.userStories.map(x=>`- [${x.priority||'P2'}] ${x.story||'未描述'} → 验收: ${x.acceptance||'未定义'}`).join('\n') : '未定义用户故事';
    const m = f1.modules?.length > 0 ? f1.modules.map(x=>`- [${x.priority||'P2'}] ${x.name}: ${x.desc||''}`).join('\n') : '未定义模块';
    const nf = f1.nonFunctional || {};
    const nfs = Object.entries(nf).filter(([,v])=>v&&v.trim()).map(([k,v])=>`- ${k}: ${v}`).join('\n') || '未定义';
    return `<form-1>\n## 表单1：PRD需求定义（第一阶段·需求收敛）\n\n### 用户角色画像\n${r}\n\n### 核心使用场景\n${sc}\n\n### 用户故事\n${st}\n\n### 功能模块\n${m}\n\n### 非功能需求\n${nfs}\n</form-1>`;
  }
  generateForm2(f2) {
    if (!f2) return '';
    const ma = f2.moduleAcceptance?.length > 0 ? f2.moduleAcceptance.map(x=>`- [${x.priority||'P2'}] ${x.name}: ${x.funcCriteria||''}`).join('\n') : '未定义';
    const tc = f2.testCases?.length > 0 ? f2.testCases.slice(0,10).map(x=>`- [${x.priority||'P2'}] ${x.name}: ${x.expected||''}`).join('\n') + (f2.testCases.length>10?`\n... 共${f2.testCases.length}条用例`:'') : '未定义测试用例';
    const dr = f2.defectRules || {};
    return `<form-2>\n## 表单2：TDD测试定义（第二阶段·标准前置）\n\n### 分模块验收标准\n${ma}\n\n### 功能测试用例（前10条）\n${tc}\n\n### 缺陷分级规则\n- **P0致命**: ${dr.grading?dr.grading.split('\n')[0]||'未定义':'未定义'}\n- **提交准入**: ${dr.commitGate||'未定义'}\n</form-2>`;
  }
  generateForm3(f3) {
    if (!f3) return '';
    const mo = f3.moduleOverview || {};
    const sp = f3.featureDevSpecs?.length > 0 ? f3.featureDevSpecs.slice(0,5).map(x=>`- [${x.priority||'P2'}] ${x.name}: ${x.desc||''}`).join('\n') + (f3.featureDevSpecs.length>5?`\n... 共${f3.featureDevSpecs.length}个功能点`:'') : '未定义';
    const tc = f3.techConstraints || {};
    return `<form-3>\n## 表单3：模块开发要求（第三阶段·执行落地）\n\n### 模块开发总览\n- **核心目标**: ${mo.coreGoal||'未定义'}\n- **前置依赖**: ${mo.preDeps||'无'}\n- **后续影响**: ${mo.postImpact||'无'}\n\n### 功能点开发规格（前5个）\n${sp}\n\n### 技术实现硬约束\n- **技术栈**: ${tc.techStack||'继承表单0约束'}\n- **架构**: ${tc.architecture||'未定义'}\n- **安全**: ${tc.security||'未定义'}\n- **性能**: ${tc.performance||'未定义'}\n</form-3>`;
  }
  generateForm4(f4) {
    if (!f4) return '';
    const r = f4.risks?.length > 0 ? f4.risks.map(x=>`- [${x.level||'中'}] ${x.desc||'未描述'} (概率:${x.probability||'?'} 影响:${x.impact||'?'})`).join('\n') : '未识别风险';
    return `<form-4>\n## 表单4：风险矩阵管控（全环节通用）\n\n### 已识别风险\n${r}\n\n### 风险分级规则\n- **高风险**: ${f4.riskRules?.high||'未定义'}\n- **中风险**: ${f4.riskRules?.medium||'未定义'}\n</form-4>`;
  }
  generateForm5(f5) {
    if (!f5) return '';
    const pa = f5.phaseAcceptance?.length > 0 ? f5.phaseAcceptance.map(x=>`- [${x.status||'待检'}] ${x.phase}: ${x.item||''} → ${x.passCriteria||''}`).join('\n') : '未定义验收项';
    return `<form-5>\n## 表单5：验收标准（全环节闭环校验）\n\n### 分阶段验收\n${pa}\n\n### 一票否决项\n${f5.defectRules?.vetoItems||'未定义'}\n</form-5>`;
  }
  generateForm6(f6) {
    if (!f6) return '';
    const gc = f6.globalConfig || {};
    return `<form-6>\n## 表单6：输出配置（全环节通用）\n\n### 全局配置\n- **语言**: ${gc.language||'中文'}\n- **安全级别**: ${gc.securityLevel||'未定义'}\n- **品牌标识**: ${gc.branding||'未定义'}\n</form-6>`;
  }
  generateFooter() { return `---\n> 此 Prompt 由 FlowPrompt Studio v3.0 生成\n> 方法论：6表单全链路工程化AI开发体系\n> 表单0·核心基础信息 → 表单1·PRD需求 → 表单2·TDD测试 → 表单3·模块开发 → 表单4·风险管控 → 表单5·验收标准 → 表单6·输出配置\n> 硬约束红线：技术栈·合规域·数据主权·性能基线·开源许可\n> 协议：MIT`; }
  generateSummary(fd) {
    try { const f0=fd.form0||{}; const f1=fd.form1||{}; const f2=fd.form2||{}; return { success:true, message:'摘要生成成功', data:`**项目**: ${f0.projectName||'未定义'}\n**核心目标**: ${f0.coreGoal?f0.coreGoal.substring(0,50):'未定义'}\n**用户角色**: ${f1.userRoles?f1.userRoles.length:0} 个\n**功能模块**: ${f1.modules?f1.modules.length:0} 个\n**测试用例**: ${f2.testCases?f2.testCases.length:0} 条\n**技术栈约束**: ${f0.techStackConstraint||'未设定'}\n**宿主环境**: ${f0.hostEnv||'未设定'}` }; } catch(e) { return { success:false, message:'摘要生成失败', error:e.message }; }
  }
  optimizePrompt(p) { try { return { success:true, message:'Prompt 优化成功', data:p.replace(/\n{3,}/g,'\n\n').trim() }; } catch(e) { return { success:false, message:'Prompt 优化失败', error:e.message }; } }
}

module.exports = FlowPromptGeneratorSkill;

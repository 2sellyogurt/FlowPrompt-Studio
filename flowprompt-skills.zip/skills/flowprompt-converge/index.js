/**
 * FlowPrompt Studio - 全链路工程化AI开发技能集
 * Copyright (C) 2026 FlowPrompt Studio Team
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Affero General Public License as published
 * by the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU Affero General Public License for more details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program. If not, see <https://www.gnu.org/licenses/>.
 */

const FlowPromptConvergeSkill = require('./src/convergeSkill');

class FlowPromptConverge {
  constructor() {
    this.skill = new FlowPromptConvergeSkill();
  }

  run({ action, data }) {
    switch (action) {
      case 'start':
        return this.skill.start(data.userInput);
      case 'answer':
        return this.skill.answer(data.context, data.userAnswer);
      case 'quickConverge':
        return this.skill.quickConverge(data.userInput);
      case 'getNextQuestion':
        return { success: true, data: this.skill.getNextQuestion(data.context) };
      case 'validateDraft':
        return { success: true, data: this.skill.validateDraft(data.formDraft) };
      default:
        return { success: false, message: `未知操作: ${action}` };
    }
  }
}

module.exports = FlowPromptConverge;

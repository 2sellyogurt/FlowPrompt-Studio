/**
 * FlowPrompt Studio - 全链路工程化AI开发技能集
 * Copyright (C) 2026 FlowPrompt Studio Team
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Affero General Public License as published
 * by the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU Affero General Public License for more details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program. If not, see <https://www.gnu.org/licenses/>.
 */

// FlowPrompt-Converge 技能 v1.0
// 需求收敛引擎：将模糊想法收敛为7表单可用的结构化数据
// 核心逻辑：5轮渐进式提问 → 每轮分析回答 → 自动映射到表单字段

class FlowPromptConvergeSkill {
  /**
   * 启动收敛流程
   * 输入：用户的一句话模糊想法
   * 输出：第一轮问题 + 初始化的收敛上下文
   */
  start(userInput) {
    try {
      const context = {
        rawInput: userInput,
        phase: 0,  // 0-4 共5轮
        answers: [],
        formDraft: this.getEmptyDraft(),
        confidence: 0,
        missingFields: this.analyzeMissing(userInput)
      };

      const firstQuestion = this.getNextQuestion(context);

      return {
        success: true,
        message: '需求收敛已启动',
        data: {
          phase: 0,
          question: firstQuestion,
          options: firstQuestion.options || null,
          context,
          progress: '1/5'
        }
      };
    } catch (error) {
      return { success: false, message: '启动失败', error: error.message || '未知错误' };
    }
  }

  /**
   * 处理用户回答，进入下一轮
   */
  answer(context, userAnswer) {
    try {
      context.answers.push({
        phase: context.phase,
        question: this.getNextQuestion(context).text,
        answer: userAnswer,
        timestamp: Date.now()
      });

      // 将回答映射到表单字段
      this.mapAnswerToDraft(context, context.phase, userAnswer);

      context.phase++;

      // 检查是否完成
      if (context.phase >= 5) {
        context.confidence = this.calculateConfidence(context);
        const validation = this.validateDraft(context.formDraft);
        return {
          success: true,
          message: '需求收敛完成',
          data: {
            phase: 5,
            finished: true,
            formDraft: context.formDraft,
            confidence: context.confidence,
            validation,
            missingFields: this.getRemainingMissing(context.formDraft),
            extractedFields: this.getExtractedFields(context.formDraft),
            progress: '5/5'
          }
        };
      }

      const nextQuestion = this.getNextQuestion(context);
      return {
        success: true,
        message: '继续收敛',
        data: {
          phase: context.phase,
          question: nextQuestion,
          options: nextQuestion.options || null,
          context,
          progress: `${context.phase + 1}/5`
        }
      };
    } catch (error) {
      return { success: false, message: '处理失败', error: error.message || '未知错误' };
    }
  }

  /**
   * 5轮收敛问题定义
   * 每轮聚焦一个维度，问题由简到深
   */
  getNextQuestion(context) {
    const questions = [
      {
        text: '你想做什么？用一句话描述你的核心目标（例如："帮开发者用AI写代码时少走弯路"）',
        hint: '不需要技术细节，说清楚"解决谁的什么问题"就行',
        options: ['工具类（提升效率）', '平台类（连接多方）', '内容类（生成/分析）', '其他']
      },
      {
        text: '谁会用这个东西？他们现在怎么解决这个问题的？',
        hint: '越具体越好，比如"初级前端开发者，现在靠Google搜索和问同事"',
        options: ['开发者', '设计师', '产品经理', '非技术人员', '其他']
      },
      {
        text: '你打算用什么技术栈？有没有什么技术是绝对不能用或必须用的？',
        hint: '比如"必须用TypeScript，不能用Python"',
        options: ['前端（React/Vue）', '后端（Node/Python）', '全栈', '桌面端', '其他']
      },
      {
        text: '做到什么程度算成功？有没有什么是一定不能出错的地方？',
        hint: '比如"数据不能丢""响应<200ms""必须兼容VS Code 1.80+"',
        options: ['功能正确就行', '性能有要求', '安全有要求', '都有要求']
      },
      {
        text: '最后确认：有没有遗漏的关键信息？比如项目周期、合规要求、已有的代码或资料？',
        hint: '没有的话直接说"没有了"也可以',
        options: ['没有了', '有，补充：...']
      }
    ];

    const q = questions[context.phase] || questions[4];
    return q;
  }

  /**
   * 将用户回答映射到表单字段
   * 核心逻辑：关键词提取 + 智能填充
   */
  mapAnswerToDraft(context, phase, answer) {
    const draft = context.formDraft;
    const text = answer.toLowerCase();

    switch (phase) {
      case 0: // 核心目标
        draft.form0.projectName = this.extractProjectName(answer) || draft.form0.projectName;
        draft.form0.coreGoal = answer.length > 200 ? answer.substring(0, 200) : answer;
        // 提取核心价值
        if (text.includes('效率') || text.includes('快') || text.includes('省')) {
          draft.form0.coreValue.push('提升效率');
        }
        if (text.includes('质量') || text.includes('准确') || text.includes('减少错误')) {
          draft.form0.coreValue.push('提升质量');
        }
        if (text.includes('标准化') || text.includes('规范') || text.includes('流程')) {
          draft.form0.coreValue.push('标准化流程');
        }
        break;

      case 1: // 用户与场景
        draft.form0.targetUsers = answer;
        // 提取用户角色
        const roles = this.extractRoles(answer);
        if (roles.length > 0) {
          draft.form1.userRoles = roles.map(name => ({
            name,
            painPoints: '',
            needs: '',
            profile: ''
          }));
        }
        // 提取使用场景
        const scenarios = this.extractScenarios(answer);
        if (scenarios.length > 0) {
          draft.form1.scenarios = scenarios.map((desc, i) => ({
            sceneId: `S${i + 1}`,
            name: desc.substring(0, 30),
            flow: desc,
            priority: 'P1'
          }));
        }
        break;

      case 2: // 技术约束
        draft.form0.techStackConstraint = answer;
        draft.form0.hostEnv = this.extractHostEnv(answer) || draft.form0.hostEnv;
        // 提取排除项
        const excludes = this.extractExcludes(answer);
        if (excludes.length > 0) {
          draft.form0.techStackConstraint = answer;
          draft.form5.excludedFeatures = excludes;
        }
        break;

      case 3: // 验收标准
        // 提取量化指标
        const metrics = this.extractMetrics(answer);
        if (metrics.length > 0) {
          draft.form4.acceptanceCriteria = metrics.map(m => ({
            description: m.desc,
            metric: m.metric,
            targetValue: m.target,
            priority: 'P0'
          }));
        }
        // 提取一票否决项
        const vetoKeywords = ['不能丢', '不能错', '不能崩', '绝对不能', '必须', '一定不能'];
        const vetoItems = vetoKeywords.filter(kw => text.includes(kw));
        if (vetoItems.length > 0) {
          draft.form5.defectRules.vetoItems = answer;
        }
        // 提取性能要求
        const perf = this.extractPerformance(answer);
        if (perf) {
          draft.form0.perfBaseline = perf;
        }
        break;

      case 4: // 补充信息
        // 提取项目周期
        const dates = this.extractDates(answer);
        if (dates.start) draft.form0.startDate = dates.start;
        if (dates.end) draft.form0.launchDate = dates.end;
        // 提取合规要求
        if (text.includes('合规') || text.includes('安全') || text.includes('隐私')) {
          draft.form0.complianceDomain = answer;
        }
        // 提取已有资产
        if (text.includes('已有') || text.includes('现有') || text.includes('参考')) {
          draft.form0.existingAssets = answer;
        }
        break;
    }
  }

  // ─── 提取辅助方法 ───

  extractProjectName(text) {
    // 从回答中提取项目名称（取前10个字符作为名称）
    const cleaned = text.replace(/[，。、！？,.!?]/g, ' ').trim();
    const words = cleaned.split(/\s+/);
    if (words.length >= 2) {
      return words.slice(0, Math.min(4, words.length)).join('');
    }
    return cleaned.substring(0, 15);
  }

  extractRoles(text) {
    const roleKeywords = ['开发者', '工程师', '设计师', '产品经理', '运营', '学生', '用户', '前端', '后端', '全栈', '测试', '管理员', '非技术人员'];
    return roleKeywords.filter(kw => text.includes(kw));
  }

  extractScenarios(text) {
    const scenarios = [];
    const sceneKeywords = [
      { kw: ['开发', '写代码', '编程'], desc: '新功能开发' },
      { kw: ['修复', 'bug', '改bug', '调试'], desc: 'Bug修复' },
      { kw: ['重构', '优化', '改进'], desc: '代码重构' },
      { kw: ['测试', '验证', '检查'], desc: '测试验证' },
      { kw: ['部署', '上线', '发布'], desc: '部署上线' },
      { kw: ['分析', '查看', '监控'], desc: '数据分析' },
      { kw: ['生成', '创建', '写'], desc: '内容生成' },
      { kw: ['管理', '配置', '设置'], desc: '配置管理' }
    ];
    for (const s of sceneKeywords) {
      if (s.kw.some(kw => text.includes(kw))) {
        scenarios.push(s.desc);
      }
    }
    return scenarios;
  }

  extractHostEnv(text) {
    const envMap = [
      { kw: ['vs code', 'vscode', '插件', 'extension'], env: 'VS Code Extension' },
      { kw: ['web', '网站', '网页', '浏览器'], env: 'Web Browser' },
      { kw: ['手机', 'app', '移动', 'ios', 'android'], env: 'Mobile App' },
      { kw: ['桌面', 'electron', '客户端'], env: 'Desktop App' },
      { kw: ['cli', '命令行', '终端', '命令'], env: 'CLI Tool' },
      { kw: ['后端', '服务端', 'server', 'api'], env: 'Server' }
    ];
    const found = envMap.find(e => e.kw.some(kw => text.includes(kw)));
    return found ? found.env : '';
  }

  extractExcludes(text) {
    const excludes = [];
    const excludeKeywords = ['不能用', '禁止', '不要用', '排除', '不用', '避免'];
    for (const kw of excludeKeywords) {
      if (text.includes(kw)) {
        const after = text.split(kw)[1];
        if (after) {
          const tech = after.trim().split(/[，。、\s,]/)[0].trim();
          if (tech.length > 0 && tech.length < 20) excludes.push(tech);
        }
      }
    }
    return excludes;
  }

  extractMetrics(text) {
    const metrics = [];
    const patterns = [
      { regex: /(\d+)\s*(ms|毫秒|秒|s)/gi, type: '性能' },
      { regex: /(\d+)\s*(%|百分比)/gi, type: '覆盖率' },
      { regex: /(\d+)\s*(个|条|项|次)/gi, type: '数量' }
    ];
    for (const p of patterns) {
      const matches = text.match(p.regex);
      if (matches) {
        metrics.push({ desc: p.type + '指标', metric: p.type, target: matches[0] });
      }
    }
    // 非量化的验收标准
    const qualKeywords = ['不能丢', '不能错', '不能崩', '必须兼容', '必须支持'];
    for (const kw of qualKeywords) {
      if (text.includes(kw)) {
        const idx = text.indexOf(kw);
        metrics.push({ desc: text.substring(Math.max(0, idx - 5), idx + kw.length + 10), metric: '定性', target: kw });
      }
    }
    return metrics;
  }

  extractPerformance(text) {
    const perfMatch = text.match(/(\d+)\s*(ms|毫秒|秒|s)/);
    if (perfMatch) return '响应时间' + perfMatch[0];
    if (text.includes('快') || text.includes('性能')) return '高性能（具体指标待定）';
    return '';
  }

  extractDates(text) {
    const result = {};
    const dateMatch = text.match(/(\d{4})[/-](\d{1,2})[/-](\d{1,2})/g);
    if (dateMatch && dateMatch.length >= 1) result.start = dateMatch[0];
    if (dateMatch && dateMatch.length >= 2) result.end = dateMatch[1];
    const monthMatch = text.match(/(\d+)\s*(个月|月|周|周)/);
    if (monthMatch && !result.end) result.end = '约' + monthMatch[0] + '后';
    return result;
  }

  // ─── 分析与验证 ───

  analyzeMissing(userInput) {
    const text = userInput.toLowerCase();
    const missing = [];
    if (userInput.length < 10) missing.push('核心目标描述太短');
    if (!/\d/.test(text) && !text.includes('快') && !text.includes('慢')) missing.push('无量化指标');
    return missing;
  }

  getRemainingMissing(draft) {
    const missing = [];
    if (!draft.form0.projectName) missing.push('form0.projectName');
    if (!draft.form0.coreGoal || draft.form0.coreGoal.length < 10) missing.push('form0.coreGoal');
    if (!draft.form0.techStackConstraint) missing.push('form0.techStackConstraint');
    if (!draft.form0.hostEnv) missing.push('form0.hostEnv');
    if (!draft.form0.targetUsers) missing.push('form0.targetUsers');
    if (draft.form1.userRoles.length === 0) missing.push('form1.userRoles');
    if (draft.form5.defectRules.vetoItems) missing.push('form5.vetoItems（已自动提取）');
    return missing;
  }

  calculateConfidence(context) {
    const filled = this.getRemainingMissing(context.formDraft);
    // 只统计真正缺失的项（排除已自动提取的）
    const realMissing = filled.filter(f => !f.includes('已自动提取')).length;
    // 额外检查：如果核心字段内容质量低，降低置信度
    let qualityPenalty = 0;
    const f0 = context.formDraft.form0;
    if (f0.coreGoal && f0.coreGoal === context.rawInput) qualityPenalty += 15; // 整段复制说明没提取
    if (f0.techStackConstraint && f0.techStackConstraint === context.rawInput) qualityPenalty += 15;
    if (f0.projectName && f0.projectName.length > 20) qualityPenalty += 10; // 项目名太长说明没提取
    return Math.max(0, Math.min(100, Math.round((1 - realMissing / 7) * 100 - qualityPenalty)));
  }

  validateDraft(draft) {
    const errors = [];
    const warnings = [];
    if (!draft.form0.projectName) warnings.push('建议补充项目名称');
    if (!draft.form0.coreGoal || draft.form0.coreGoal.length < 10) warnings.push('核心目标描述较短，建议补充');
    if (!draft.form0.techStackConstraint) warnings.push('建议明确技术栈约束');
    if (draft.form1.userRoles.length === 0) warnings.push('建议补充用户角色');
    return { isValid: errors.length === 0, errors, warnings };
  }

  getEmptyDraft() {
    return {
      form0: {
        projectName: '', coreGoal: '', coreValue: [], targetUsers: '', deliverables: [],
        hostEnv: '', techStackConstraint: '', complianceDomain: '', dataPolicy: '',
        licenseReq: '', perfBaseline: '', startDate: '', launchDate: '',
        milestones: '', productOwner: '', techOwner: '', testOwner: '', changeApproval: ''
      },
      form1: {
        userRoles: [], scenarios: [], userStories: [], modules: [], features: [],
        nonFunctional: {}, changeControl: {}, review: {}
      },
      form2: { moduleAcceptance: [], testCases: [], nonFuncCases: [], testEnv: {}, defectRules: {}, review: {} },
      form3: { moduleOverview: {}, featureDevSpecs: [], techConstraints: {}, delivery: {}, progress: {} },
      form4: { risks: [], mitigations: [], riskRules: {}, emergencyPlans: [], tracking: {} },
      form5: { phaseAcceptance: [], specialAcceptance: [], defectRules: { vetoItems: '' }, reviewRecords: [], archive: {} },
      form6: { globalConfig: {}, stageOutput: [], formatConfig: [], aiTemplates: [], channels: [], archiveConfig: {} }
    };
  }

  /**
   * 一键收敛（非交互模式）
   * 直接从用户输入一次性提取所有可识别信息
   */
  quickConverge(userInput) {
    try {
      const context = {
        rawInput: userInput,
        phase: 0,
        answers: [],
        formDraft: this.getEmptyDraft(),
        confidence: 0,
        missingFields: []
      };

      // 一次性分析所有维度
      this.mapAnswerToDraft(context, 0, userInput);
      this.mapAnswerToDraft(context, 1, userInput);
      this.mapAnswerToDraft(context, 2, userInput);
      this.mapAnswerToDraft(context, 3, userInput);
      this.mapAnswerToDraft(context, 4, userInput);

      context.confidence = this.calculateConfidence(context);
      const validation = this.validateDraft(context.formDraft);

      return {
        success: true,
        message: '一键收敛完成',
        data: {
          formDraft: context.formDraft,
          confidence: context.confidence,
          validation,
          missingFields: this.getRemainingMissing(context.formDraft),
          extractedFields: this.getExtractedFields(context.formDraft)
        }
      };
    } catch (error) {
      return { success: false, message: '收敛失败', error: error.message || '未知错误' };
    }
  }

  getExtractedFields(draft) {
    const extracted = [];
    if (draft.form0.projectName) extracted.push('项目名称');
    if (draft.form0.coreGoal) extracted.push('核心目标');
    if (draft.form0.coreValue.length > 0) extracted.push('核心价值(' + draft.form0.coreValue.length + '条)');
    if (draft.form0.targetUsers) extracted.push('目标用户');
    if (draft.form0.techStackConstraint) extracted.push('技术栈约束');
    if (draft.form0.hostEnv) extracted.push('宿主环境');
    if (draft.form0.perfBaseline) extracted.push('性能基线');
    if (draft.form1.userRoles.length > 0) extracted.push('用户角色(' + draft.form1.userRoles.length + '个)');
    if (draft.form1.scenarios.length > 0) extracted.push('使用场景(' + draft.form1.scenarios.length + '个)');
    if (draft.form5.defectRules.vetoItems) extracted.push('一票否决项');
    return extracted;
  }
}

module.exports = FlowPromptConvergeSkill;
